"""
Problem2
 Compute the age of a person in number of days. So, given the date of birth
of a person in the format dd mm yyyy (three integers) and the current date
(in the same format) compute the age of that person in number of days.
"""






def age(d1, m1, y1, d2, m2, y2):
    pass


if __name__ == '__main__':
    pass
    d1, m1, y1, d2, m2, y2 = 20, 3, 2001, 20, 3, 2002
    # print_hi('PyCharm')
    print(age(d1, m1, y1, d2, m2, y2))


