"""

@author: radu

Write an application which manages the students of a faculty.
Each student has a unique id, a name and a grade. The application should
allow to:

F1: print all students
F2: add students
F3: delete students
F4: show students whose grades are >= a given value
F5: find a student with the maximal grade
F6_: split the application into modules (main, ui, domain, util)
F7_: validate input data
F8_: student_id is unique - validation in add, delete etc.
F9: find all students whose name contain a string t (the match should not be
    case sensitive)
F10: undo
F11: remove all students with the grade smaller than 5 (using TDD)
F12: sort students according to their grade (descending)  (using TDD)
F13: given an integer 'nr', find the top nr students according
     to their grade  (using TDD)
F14: compute the average grade of all students having the grade >= 5 (using TDD)
F15: sort all students according to their grade and alphabetically (using TDD).
------------

I1: F2, F1, F3, F4, F5
I2: F6_, F7_
I3: F8_, F9
I4: F10
I5: F11, F12, F13, F14, F15
------------------------
------------------------
s= 1, "s1", 10
------
s={"id":1, "name":"s1", "grade":10} -> print(s["name"]) -> print(get_name(s))
s=[1,"s1",10] -> print(s[1])
s=(1,"s1",10) -> print(s[1])

l=[ , , , , ]


"""


# =============================== domain ==========================================
def create_student(id, name, grade):
    return {"id": id, "name": name, "grade": grade}


def get_id(student):
    return student["id"]


def set_id(student, id):
    student["id"] = id


def get_name(student):
    return student["name"]


# todo: getters and settters for name and grade

# ================================ operations ==========================

def add_student(students, id, name, grade):
    # todo: check id
    student = create_student(id, name, grade)
    students.append(student)


# =============================== ui =================================

def ui_add_student(students):
    print("adding a new student")

    id = int(input("id="))
    name = input("name=")
    grade = int(input("grade="))

    add_student(students, id, name, grade)


def ui_print_all_students(students):
    # todo: DURING THE SEMINAR: print students in a user friendly fashion
    print(students)


def print_options():
    print("1 - add student\n"
          "2 - print all students \n"
          "x - exit")


def run_menu():
    students = []
    options = {1: ui_add_student, 2: ui_print_all_students}
    while True:
        print_options()
        opt = input("opt=")
        if opt == "x":
            break
        opt = int(opt)
        options[opt](students)

        """
        if opt == 1 
          then call ui_add_student
        if opt == 2
          then call the ui print all fn
        ......... etc etc etc
        """


if __name__ == '__main__':
    print("hello")

    run_menu()

    print("bye")
