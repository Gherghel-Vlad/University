"""
Problem2
 Compute the age of a person in number of days. So, given the date of birth
of a person in the format dd mm yyyy (three integers) and the current date
(in the same format) compute the age of that person in number of days.
"""


# def print_hi(name):
#     # Use a breakpoint in the code line below to debug your script.
#     print(f'Hi, {name}')  # Press Ctrl+F8 to toggle the breakpoint.


def age(d1, m1, y1, d2, m2, y2):
    pass


if __name__ == '__main__':
    pass
    # print_hi('PyCharm')
    d1, m1, y1, d2, m2, y2 = 20, 3, 2001, 20, 3, 2002
    print(age(d1, m1, y1, d2, m2, y2))

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
